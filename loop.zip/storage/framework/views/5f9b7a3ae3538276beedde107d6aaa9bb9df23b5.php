<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item active"><a href="">Category Result</a></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content-backend'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card m-b-30">
                <div class="card-body">
                    <ul class="list-unstyled nav">
                        <div class="table-responsive" style="width: 20%;">
                            <table class="table table-striped table-bordered">
                                <tbody>
                                    <tr>
                                        <th>Nama</th>
                                        <td><?php echo e($user->name); ?></td>
                                    </tr>
                                    <tr>
                                        <th>NIM</th>
                                        <td><?php echo e($user->nim); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Kelas</th>
                                        <td><?php echo e($user->kelas); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'superadmin')): ?>
                            <li class="nav-item ml-3"><a href="<?php echo e(route('user.create')); ?>"><i class="mdi mdi-animation"></i></a>
                            </li>
                        <?php endif; ?>
                    </ul>


                    <table id="datatable-buttons" class="table table-striped table-bordered w-100 text-center">


                        <thead>
                            <tr>
                                <th>Category</th>
                                <th>Poin</th>
                                <th>Action</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php $__currentLoopData = $user->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($category->name); ?></td>
                                    <td><?php echo e($category->nilai); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('log.last.result', ['user' => $user->id, 'categoryId' => $category->id])); ?>"
                                            class="btn btn-info btn-sm btn-edit">
                                            <i class="mdi mdi-eye"></i> see
                                        </a>
                                        
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div> <!-- end col -->
    </div> <!-- end row -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-script'); ?>
    <!-- Required datatable js -->
    <script src="<?php echo e(asset('assets_backend/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets_backend/plugins/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
    <!-- Buttons examples -->
    <script src="<?php echo e(asset('assets_backend/plugins/datatables/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets_backend/plugins/datatables/buttons.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets_backend/plugins/datatables/jszip.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets_backend/plugins/datatables/pdfmake.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets_backend/plugins/datatables/vfs_fonts.js')); ?>"></script>
    <script src="<?php echo e(asset('assets_backend/plugins/datatables/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets_backend/plugins/datatables/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets_backend/plugins/datatables/buttons.colVis.min.js')); ?>"></script>
    <!-- Responsive examples -->
    <script src="<?php echo e(asset('assets_backend/plugins/datatables/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets_backend/plugins/datatables/responsive.bootstrap4.min.js')); ?>"></script>

    <!-- Datatable init js -->
    <script src="<?php echo e(asset('assets_backend/pages/datatables.init.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend', ['title' => 'Log Activity-Category Result'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SKRIPSI\jasa\loop-main-otherB 5_FINAL\loop-main-otherB\resources\views/backend/pages/logActivity/categoryResult.blade.php ENDPATH**/ ?>
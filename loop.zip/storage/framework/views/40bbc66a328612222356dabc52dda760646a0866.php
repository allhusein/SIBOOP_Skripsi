 <!-- ========== Left Sidebar Start ========== -->
 <div class="left side-menu">
     <button type="button" class="button-menu-mobile button-menu-mobile-topbar open-left waves-effect">
         <i class="mdi mdi-close"></i>
     </button>

     <!-- LOGO -->
     <div class="topbar-left">
         <div class="text-center">
             <!--<a href="index.html" class="logo"><i class="mdi mdi-assistant"></i> Urora</a>-->
             <a href="<?php echo e(route('home')); ?>" class="logo">
                 <img src="<?php echo e(asset('assets_backend/images/logo-dashboard.png')); ?>" alt="logo-loop" class="logo-large">
             </a>
         </div>
     </div>

     <div class="sidebar-inner slimscrollleft" id="sidebar-main">

         <div id="sidebar-menu">
             <ul>
                 <li class="menu-title">Main</li>

                 <li>
                     <a href="<?php echo e(route('home')); ?>" class="waves-effect" id="/">
                         <i class="mdi mdi-view-dashboard"></i>
                         <span> Dashboard </span>
                     </a>
                 </li>
                 <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'superadmin|dosen')): ?>
                     <li>
                         <a href="<?php echo e(route('user.index')); ?>" class="waves-effect" id="/user">
                             <i class="mdi mdi-account"></i>
                             <span> User Manajemen </span>
                         </a>
                     </li>
                 <?php endif; ?>

                 <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'mahasiswa|dosen')): ?>
                     <li class="has_sub">
                         <a class="waves-effect"><i class="mdi mdi-animation"></i> <span> Latihan Materi </span> <span
                                 class="float-right"><i class="mdi mdi-chevron-right"></i></span></a>
                         <ul class="list-unstyled">
                             <li><a href="<?php echo e(route('category.index')); ?>">Kategori</a></li>
                         </ul>
                     </li>
                 <?php endif; ?>
                 <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'dosen')): ?>
                     <li class="has_sub">
                         <a class="waves-effect"><i class="mdi mdi-history"></i> <span>Aktivitas</span>
                             <span class="float-right"><i class="mdi mdi-chevron-right"></i></span></a>
                         </i></span></a>
                         <ul class="list-unstyled">
                             <li><a href="<?php echo e(route('log.index')); ?>">Log Aktivitas</a></li>
                             <li><a href="<?php echo e(route('confidence.index')); ?>">History Confidence Tag</a></li>
                         </ul>
                     </li>
                 <?php endif; ?>
             </ul>
         </div>
         <div class="clearfix"></div>
     </div>
     <!-- end sidebarinner -->
 </div>
 <!-- Left Sidebar End -->

 <?php $__env->startPush('after-script'); ?>
     <script>
         const url = window.location.pathname.split(("/"));
         const getSide = document.getElementById("/" + url[2]);
         getSide.classList.add('active');
     </script>
 <?php $__env->stopPush(); ?>
<?php /**PATH /home/ditya/Documents/www/loop-main-otherB/resources/views/backend/include/sidebar.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
        <title>Loop App</title>
        <meta content="Admin Dashboard" name="description" />
        <meta content="Mannatthemes" name="author" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />

        <link rel="shortcut icon" href="<?php echo e(asset('assets_backend/images/favicon.ico')); ?>">

        <link href="<?php echo e(asset('assets_backend/plugins/animate/animate.css')); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo e(asset('assets_backend/css/bootstrap-material-design.min.css')); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo e(asset('assets_backend/css/icons.css')); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo e(asset('assets_backend/css/style.css')); ?>" rel="stylesheet" type="text/css">

    </head>
    <body>


    <!-- Begin page -->
    
    <div class="wrapper-page">
        <div class="display-table">
            <div class="display-table-cell">
                <diV class="container">
                    <div class="row justify-content-center">
                        <div class="col-md-6">
                            <div class="card">
                                <div class="card-body">
                                        <div class="text-center pt-3">
                                            <a href="<?php echo e(route('home')); ?>">
                                                <img src="<?php echo e(asset('assets_backend/images/logo-login.png')); ?>" alt="logo-loop" height="170" />
                                            </a>
                                        </div>
                                        <div class="px-3 pb-3">
                                            <form method="POST" action="<?php echo e(route('login')); ?>">
                                                <?php echo csrf_field(); ?>
                                                <div class="form-group row">
                                                    <div class="col-12">
                                                        <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" placeholder="Email" required autocomplete="email">

                                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($message); ?></strong>
                                                            </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                                <div class="form-group row">
                                                    <div class="col-12">
                                                        <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Password" name="password" required autocomplete="current-password">

                                                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($message); ?></strong>
                                                            </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                                <div class="form-group text-right row m-t-20">
                                                    <div class="col-12">
                                                        <button class="btn btn-primary btn-raised btn-block waves-effect waves-light" type="submit">Log In</button>
                                                    </div>
                                                </div>
                                                <div class="text-right">
                                                <?php if(Route::has('register')): ?>
                                                    <a href="<?php echo e(route('register.mahasiswa')); ?>" class="ml-4 text-sm text-gray-700 dark:text-gray-500 underline">Belum punya akun ?</a>
                                                <?php endif; ?>
                                                </div>
                                            </form>
                                        </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </diV>
            </div>
        </div>
    </div>



        <!-- jQuery  -->
        <script src="<?php echo e(asset('assets_backend/js/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets_backend/js/popper.min.js')); ?>"></script>
         <script src="<?php echo e(asset('assets_backend/js/bootstrap-material-design.js')); ?>"></script>
         <script src="<?php echo e(asset('assets_backend/js/modernizr.min.js')); ?>"></script>
         <script src="<?php echo e(asset('assets_backend/js/detect.js')); ?>"></script>
         <script src="<?php echo e(asset('assets_backend/js/fastclick.js')); ?>"></script>
         <script src="<?php echo e(asset('assets_backend/js/jquery.slimscroll.js')); ?>"></script>
         <script src="<?php echo e(asset('assets_backend/js/jquery.blockUI.js')); ?>"></script>
         <script src="<?php echo e(asset('assets_backend/js/waves.js')); ?>"></script>
         <script src="<?php echo e(asset('assets_backend/js/jquery.nicescroll.js')); ?>"></script>
         <script src="<?php echo e(asset('assets_backend/js/jquery.scrollTo.min.js')); ?>"></script>
        <?php echo $__env->make('sweetalert::alert', ['cdn' => "https://cdn.jsdelivr.net/npm/sweetalert2@9"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <!-- App js -->
        <script src="<?php echo e(asset('assets_backend/js/app.js')); ?>"></script>

    </body>
</html>
<?php /**PATH D:\SKRIPSI\jasa\loop-main-otherB 5_FINAL\loop-main-otherB\resources\views/auth/login.blade.php ENDPATH**/ ?>
<?php $__env->startSection('breadcrumb'); ?>

<li class="breadcrumb-item active"><a href="">Dashboard</a></li>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-backend'); ?>
<div class="row">
    <div class="col-md">
        Welcome to Dashboard <?php echo e(ucfirst(auth()->user()->name)); ?>

    </div>
</div>

<?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'mahasiswa')): ?>

<div class="row mt-5">
    <div class="col-md">
        <img src="<?php echo e(asset('assets_backend/images/petunjuk.png')); ?>" alt="" style="width:100%">
    </div>
</div>
<?php endif; ?>
<?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'dosen')): ?>
<div class="row mt-5">
    <div class="col-md">
        <img src="<?php echo e(asset('assets_backend/images/petunjuk-dosen.png')); ?>" alt="" style="width:100%">
    </div>
</div>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend',['title'=>'Dashboard'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\estop\OneDrive\Dokumen\Project Programing\loop-main-otherB\resources\views/backend/pages/dashboard.blade.php ENDPATH**/ ?>
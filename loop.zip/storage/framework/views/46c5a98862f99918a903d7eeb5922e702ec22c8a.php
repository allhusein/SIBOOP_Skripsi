<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item active"><a href="">Category</a></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-backend'); ?>
<div class="row">
    <div class="col-12">
        <div class="card m-b-30">
            <div class="card-body">

                <h4 class="mt-0 header-title text-center">LATIHAN MATERI KONSEP DASAR PBO</h4>
                <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'superadmin|dosen')): ?>
                <a href="<?php echo e(route('category.create')); ?>">
                    <button class="btn btn-primary rounded-sm">
                        <i class="mdi mdi-plus"></i>
                        <span> Tambah </span>
                    </button>
                </a>
                <?php endif; ?>
                <div class="row">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4">
                        <div class="col border shadow px-4 py-2 d-inline-block border-dark bg-primary">
                            <br><br>
                            <h5 class="text-white text-center"><?php echo e($cat->name); ?></h5>
                            <br><br>
                        </div>
                        <div class="col">
                            <div class="row justify-content-center">
                                <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'superadmin|dosen')): ?>
                                <form action="<?php echo e(route('question.index').'?id='.$cat->id); ?>" method="get">
                                    <input type="hidden" name="id" value="<?php echo e($cat->id); ?>">
                                    <button type="submit" class="">
                                        <i class="mdi mdi-lead-pencil"></i>
                                    </button>
                                </form>
                                <form action="<?php echo e(route('preview').'?id='.$cat->id); ?>" method="get">
                                    <input type="hidden" name="id" value="<?php echo e($cat->id); ?>">
                                    <input type="hidden" name="test" value="1">
                                    <button type="submit" class="">
                                        <i class="mdi mdi-eye"></i>
                                    </button>
                                </form>
                                <form action="<?php echo e(route('category.destroy', $cat->id)); ?>" method="post" class="need-alert">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <button type="submit" class="" >
                                        <i class="mdi mdi-delete"></i>
                                    </button>
                                </form>

                                <?php endif; ?>
                                <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'mahasiswa')): ?>
                                <a href="<?php echo e(route('exercise.index').'?id='.$cat->id); ?>">
                                    <form action="<?php echo e(route('exercise.index').'?id='.$cat->id); ?>" method="get">
                                        <input type="hidden" name="id" value="<?php echo e($cat->id); ?>">
                                        <button type="submit" class="">
                                            <i class="mdi mdi-eye"></i>
                                        </button>
                                    </form>
                                </a>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
                
            
        </div>
    </div>
</div> <!-- end col -->
</div> <!-- end row -->

<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-script'); ?>
<script>
    function archiveFunction() {
event.preventDefault(); // prevent form submit
var form = event.target.form; // storing the form
        swal({
  title: "Are you sure?",
  text: "But you will still be able to retrieve this file.",
  type: "warning",
  showCancelButton: true,
  confirmButtonColor: "#DD6B55",
  confirmButtonText: "Yes, archive it!",
  cancelButtonText: "No, cancel please!",
  closeOnConfirm: false,
  closeOnCancel: false
},
function(isConfirm){
  if (isConfirm) {
    form.submit();          // submitting the form when user press yes
  } else {
    swal("Cancelled", "Your imaginary file is safe :)", "error");
  }
});
}
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend',['title'=>'Category'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SKRIPSI\FINAL SISTEM\loop-main-otherB\resources\views/backend/pages/category/index.blade.php ENDPATH**/ ?>
<link rel="shortcut icon" href="<?php echo e(asset('assets_backend/images/favicon.ico')); ?>">

<!--Morris Chart CSS -->
<link rel="stylesheet" href="<?php echo e(asset('assets_backend/plugins/fullcalendar/vanillaCalendar.css')); ?>"/>
<link rel="stylesheet" href="<?php echo e(asset('assets_backend/plugins/jvectormap/jquery-jvectormap-2.0.2.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets_backend/plugins/chartist/css/chartist.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets_backend/plugins/morris/morris.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets_backend/plugins/metro/MetroJs.min.css')); ?>">

<link rel="stylesheet" href="<?php echo e(asset('assets_backend/plugins/carousel/owl.carousel.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets_backend/plugins/carousel/owl.theme.default.min.css')); ?>">

<link rel="stylesheet" href="<?php echo e(asset('assets_backend/plugins/animate/animate.css')); ?>" type="text/css">
<link rel="stylesheet" href="<?php echo e(asset('assets_backend/css/bootstrap-material-design.min.css')); ?>" type="text/css">
<link rel="stylesheet" href="<?php echo e(asset('assets_backend/css/icons.css')); ?>" type="text/css">
<link rel="stylesheet" href="<?php echo e(asset('assets_backend/css/style.css')); ?>" type="text/css">
<link rel="stylesheet" href="<?php echo e(asset('assets_backend/plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css')); ?>">

<?php /**PATH /Users/marthinpakpahan/Documents/Mando/loop-main-otherB/resources/views/backend/include/style.blade.php ENDPATH**/ ?>
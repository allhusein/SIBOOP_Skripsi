<!-- jQuery  -->
<script src="<?php echo e(asset('assets_backend/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets_backend/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets_backend/js/bootstrap-material-design.js')); ?>"></script>
<script src="<?php echo e(asset('assets_backend/js/modernizr.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets_backend/js/detect.js')); ?>"></script>
<script src="<?php echo e(asset('assets_backend/js/fastclick.js')); ?>"></script>
<script src="<?php echo e(asset('assets_backend/js/jquery.slimscroll.js')); ?>"></script>
<script src="<?php echo e(asset('assets_backend/js/jquery.blockUI.js')); ?>"></script>
<script src="<?php echo e(asset('assets_backend/js/waves.js')); ?>"></script>
<script src="<?php echo e(asset('assets_backend/js/jquery.nicescroll.js')); ?>"></script>
<script src="<?php echo e(asset('assets_backend/js/jquery.scrollTo.min.js')); ?>"></script>


<script src="<?php echo e(asset('assets_backend/plugins/carousel/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets_backend/plugins/fullcalendar/vanillaCalendar.js')); ?>"></script>
<script src="<?php echo e(asset('assets_backend/plugins/peity/jquery.peity.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets_backend/plugins/jvectormap/jquery-jvectormap-2.0.2.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets_backend/plugins/jvectormap/jquery-jvectormap-world-mill-en.js')); ?>"></script>
<script src="<?php echo e(asset('assets_backend/plugins/chartist/js/chartist.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets_backend/plugins/chartist/js/chartist-plugin-tooltip.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets_backend/plugins/metro/MetroJs.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets_backend/plugins/raphael/raphael.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets_backend/plugins/morris/morris.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets_backend/pages/dashborad.js')); ?>"></script>

<!-- App js -->
<script src="<?php echo e(asset('assets_backend/js/app.js')); ?>"></script>
<?php /**PATH D:\SKRIPSI\FINAL SISTEM\loop-main-otherB\resources\views/backend/include/script.blade.php ENDPATH**/ ?>
<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item"><a href="<?php echo e(route('category.index')); ?>">Category</a></li>
<li class="breadcrumb-item active"><a href="#">Create Category</a></li>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-backend'); ?>
<div class="row">
    <div class="col-md-6 col-xl-6">
        <div class="card m-b-30">
            <div class="card-body">
                <h4 class="mt-0 header-title">Create New Category</h4>
                <div class="general-label">
                    <form method="POST" action="<?php echo e(route('category.store')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="name" class="bmd-label-floating ">Name</label>
                            <input id="name" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name">

                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label for="instruction" class="bmd-label-floating ">Instruction</label>
                            <input id="instruction" type="text" class="form-control <?php $__errorArgs = ['instruction'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="instruction" value="<?php echo e(old('instruction')); ?>" required autocomplete="instruction">

                            <?php $__errorArgs = ['instruction'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <label for="time_limit" class="bmd-label-floating">Time Limit (Minutes)</label>
                            <input id="time_limit" type="number" class="form-control" name="time_limit" value="<?php echo e(old('time_limit')); ?>" required>
                            <?php $__errorArgs = ['time_limit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        
                                                  
                        <button type="submit" class="btn btn-primary btn-raised mb-0">Submit</button>
                        <button type="reset" class="btn btn-raised btn-danger mb-0">Cancel</button>
                    </form>
                </div>
            </div>
        </div>
    </div> <!-- end col -->
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend',['title'=>'category'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SKRIPSI\FINAL SISTEM\loop-main-otherB\resources\views/backend/pages/category/create.blade.php ENDPATH**/ ?>
<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item active"><a href="">Exercise</a></li>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-style'); ?>
<style>
    .bmd-form-group {
        padding : 0;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content-backend'); ?>
<div class="row">
    <div class="col-12">
        <?php if($question): ?>
        <div class="card m-b-30 pb-5">
            <div class="card-body">
                <div class="row px-5">
                    <div class="col-md-12 border-top border-bottom h5 py-3">
                        <p><b>Petunjuk Pengerjaan !</b></p>
                        <i class="mdi mdi-information"></i>
                        Drag and Drop jawaban dari kolom pilihan jawaban berwarna hijau ke kolom jawaban berwarna kuning. Total jawaban harus sesuai dan pastikan jawaban pada kotak telah berwarna biru
                    </div>
                </div>
                <div class="row px-5">
                    <div class="col-md-8 ">
                        <div class="row col-md-12">
                            <div class="card w-100 border">
                                <div class="card-body">
                                    <div class="border shadow px-4 py-2 d-inline border-dark bg-danger">Soal</div>
                                    <div class="mx-4 mt-4 mb-5"><?php echo e($question->question->question); ?></div>
                                </div>
                            </div>
                        </div>
                        <div class="row col-md-12 mt-3">
                            <div class="card w-100 border">
                                <div class="card-body">
                                    <div class="border shadow px-4 py-2 d-inline border-dark bg-warning">Jawaban</div>
                                    <div class="mx-4 mt-4 mb-5 mt-5">
                                        <div class="row text-center">
                                            <?php $forjsb=[]; ?>
                                            <form action="<?php echo e(route('previewcheck')); ?>" method="post" class="mx-auto">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="exercise_id" value="<?php echo e($question->id); ?>">
                                            <?php $__currentLoopData = $question->question->answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php array_push($forjsb,$a->id) ?>
                                            <?php if($a->is_true): ?>
                                            <div class="col-md-12 mt-4">
                                                <input id="drop<?php echo e($a->id); ?>"
                                                 name="answer[]" readonly class="border text-primary shadow px-5 py-2 d-inline border-dark" required>
                                            </div>
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <button id="submit-check" type="submit" hidden></button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card w-100 border">
                                    <div class="card-body">
                                        <div class="border shadow px-4 py-2 d-inline-block border-dark bg-success">Pilihan Jawaban</div>
                                        <div class="row text-center mt-4">
                                            <?php $forjsa=[]; ?>
                                            <?php $__currentLoopData = $question->question->answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php array_push($forjsa,$a->id) ?>

                                            <div class="col-md-12 my-3" >
                                                <div id="ans<?php echo e($a->id); ?>" class="border shadow px-4 py-2 d-inline border-dark bg-light" data-id="<?php echo e($a->id); ?>" data-answer="<?php echo e($a->answer); ?>"><?php echo e($a->answer); ?></div>
                                            </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="mt-5">
                                    <div class="row justify-content-center text-center">
                                        <div class="col-md-5 col-sm-12">
                                             <button id="submit" class="btn btn-primary">Check</button>
                                        </div>
                                        <div class="col-md-5 col-sm-12">
                                             <button class="btn btn-warning"><a href="">Reset</a></button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php else: ?>
        <div class="jumbotron jumbotron-fluid">
            <div class="container text-center">
                <h1 class="display-4">Selamat semua soal latihan sudah terjawab dengan benar</h1>
                <a href="<?php echo e(route('exercise.reset.all')); ?>"><p class="lead text-primary">Kerjakan Ulang</p></a>
            </div>
        </div>
        <?php endif; ?>
    </div> <!-- end col -->
</div> <!-- end row -->

<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-script'); ?>
<?php if(Isset($forjsa) && isset($forjsb)) : ?>
  <script src="https://code.jquery.com/ui/1.13.1/jquery-ui.js"></script>
<script>
    <?php foreach($forjsa as $fs) : ?>
        $("#ans<?=$fs?>").draggable({
            revert: "invalid",
            cursor: "move"
        });
        <?php endforeach ?>
    <?php foreach($forjsb as $fsb) : ?>

        $('#drop<?= $fsb ?>').droppable({
            drop: function( event, ui ) {
                let id =  ui.draggable.data('id');
                let answer =  ui.draggable.data('answer');

                $( this )
                .addClass( "bg-primary" )

                $( this )
                .attr('value',answer)

                $( this )
                .attr('name','answer['+id+']')
            },
            out : function(event, ui){
                $( this )
                .attr('value','')
                $( this )
                .removeClass( "bg-primary" )
                $( this )
                .attr('name','')
            }
        })
    <?php endforeach ?>

    $('#submit').on('click', function(){
        $('#submit-check').click();
    })
</script>

<?php endif ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend',['title'=>'Excercise Page'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ditya/Documents/www/loop-main-otherB/resources/views/backend/pages/preview/index.blade.php ENDPATH**/ ?>
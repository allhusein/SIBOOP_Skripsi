<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item active"><a href="">Confidence Tag History</a></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content-backend'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card m-b-30">
                <div class="card-body">
                    <ul class="list-unstyled nav">
                        <li class="nav-item">
                            <h4 class="mt-0 header-title">Confidence Tag Mahasiswa</h4>
                        </li>
                        <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'superadmin')): ?>
                            <li class="nav-item ml-3"><a href="<?php echo e(route('user.create')); ?>"><i class="mdi mdi-animation"></i></a>
                            </li>
                        <?php endif; ?>
                    </ul>
                    <table id="datatable-buttons" class="table table-striped table-bordered w-100 text-center">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>NIM</th>
                                <th>Kelas</th>
                                <th>Action</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php $__currentLoopData = $confidences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $confidence): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($confidence->user->name); ?></td>
                                    <td><?php echo e($confidence->user->nim); ?></td>
                                    <td><?php echo e($confidence->user->kelas); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('confidence.category.result', ['user' => $confidence->user->id])); ?>"
                                            class="btn btn-info btn-sm btn-edit">
                                            <i class="mdi mdi-eye"></i> see
                                        </a>
                                        <form action="<?php echo e(route('confidence.destroy', $confidence->id)); ?>" method="POST"
                                            style="display:inline;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger btn-sm btn-delete"
                                                onclick="return confirm('Are you sure you want to delete this user?')">
                                                <i class="mdi mdi-delete"></i> Delete
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div> <!-- end col -->
    </div> <!-- end row -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-script'); ?>
    <!-- Required datatable js -->
    <script src="<?php echo e(asset('assets_backend/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets_backend/plugins/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
    <!-- Buttons examples -->
    <script src="<?php echo e(asset('assets_backend/plugins/datatables/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets_backend/plugins/datatables/buttons.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets_backend/plugins/datatables/jszip.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets_backend/plugins/datatables/pdfmake.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets_backend/plugins/datatables/vfs_fonts.js')); ?>"></script>
    <script src="<?php echo e(asset('assets_backend/plugins/datatables/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets_backend/plugins/datatables/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets_backend/plugins/datatables/buttons.colVis.min.js')); ?>"></script>
    <!-- Responsive examples -->
    <script src="<?php echo e(asset('assets_backend/plugins/datatables/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets_backend/plugins/datatables/responsive.bootstrap4.min.js')); ?>"></script>

    <!-- Datatable init js -->
    <script src="<?php echo e(asset('assets_backend/pages/datatables.init.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend', ['title' => 'Confidence Tag History'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SKRIPSI\jasa\loop-main-otherB 5_FINAL\loop-main-otherB\resources\views/backend/pages/confidence/index.blade.php ENDPATH**/ ?>
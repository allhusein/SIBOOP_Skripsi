<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <link rel="shortcut icon" href="<?php echo e(asset('assets_backend/images/favicon.ico')); ?>">

    <title>Lopp Apps - <?php echo e($title); ?> Page</title>
    <meta content="Admin Dashboard" name="description" />
    <meta content="4ghel" name="developer" />

    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <?php echo $__env->make('backend.include.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldPushContent('after-style'); ?>
    <?php echo $__env->yieldPushContent('custom-css'); ?>

</head>


<body class="fixed-left">

    <!-- Loader -->
    <div id="preloader">
        <div id="status">
            <div class="spinner"></div>
        </div>
    </div>

    <div id="wrapper">
        <?php echo $__env->make('backend.include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="content-page">
            <div class="content">
                <?php echo $__env->make('backend.include.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <div class="page-content-wrapper dashborad-v">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="page-title-box">
                                    <div class="btn-group float-right">
                                        <ol class="breadcrumb hide-phone p-0 m-0">
                                            <?php echo $__env->yieldContent('breadcrumb'); ?>
                                        </ol>
                                    </div>
                                    <h4 class="page-title"><?php echo e($title); ?></h4>
                                </div>
                            </div>
                            <div class="clearfix"></div>
                        </div>

                        <?php echo $__env->yieldContent('content-backend'); ?>

                    </div>
                </div>
            </div>
            <footer class="footer">
                © 2022 Loop App - Developed By 4ghel's Team
            </footer>
        </div>
    </div>

    <?php echo $__env->make('backend.include.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('sweetalert::alert', ['cdn' => 'https://cdn.jsdelivr.net/npm/sweetalert2@9'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldPushContent('after-script'); ?>
</body>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
    $('.need-alert').on('click', function(event) {
        event.preventDefault();
        Swal.fire({
            title: 'Apakah anda yakin?',
            text: "Data yang sudah dihapus tidak dapat dikembalikan!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes'
        }).then((result) => {
            if (result.isConfirmed) {
                $(this).submit();
            }
        })
    })
</script>

</html>
<?php /**PATH /Users/marthinpakpahan/Documents/Mando/loop-main-otherB/resources/views/layouts/backend.blade.php ENDPATH**/ ?>